Debug the generateHash() function 
===================


In this activity, you will learn to debug the code to the return hash value of every character using ASCII.


<img src= "https://s3-whjr-curriculum-uploads.whjr.online/f63eab1d-63b1-46ce-a773-8d3598ea103c.png" width = "180" height = "320">




Follow the given steps to complete this activity.:
* Open the file hash.py.


* Run the code and check if each character gets hashed using an ASCII code.


* Replace the if condition with a for loop to iterate through every character in the input string instead of an if condition.


     `for char in inputString:`
    	    
* Add the encrypted characters to the hashValue variable. 


     `hashValue += ord(char)`
* Save and run the code to check the output.
