Debug the isPrime() Function 
===================


In this activity, you will debug the code to check if the range is given correctly and if True and False are returned correctly in the isPrime() function.


<img src= "https://s3-whjr-curriculum-uploads.whjr.online/b0a7910e-0fc7-456c-8fb8-af9e269ca36c.png" width = "725" height = "415">




Follow the given steps to complete this activity.
* Open the file encrypt.py.


* Check if the range is given correctly from 2 to n-1…


     `for i in range(2, n):`
    	    
* Replace "False" to "True" to return true when the number “n” is divisible by “i”.


    ` return True`   


* Try different values for num and check if the function isPrime returns a prime number.


* Save and run the code to check the output.
